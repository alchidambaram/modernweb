let myHobbies = [{ name: 'Jane', year: 5 },
{ name: 'Adam', year: 2 },
{ name: 'Dave', year: 1 }]

for (let i = 0; i < myHobbies.length; i++) {
    printHobbyInfo(myHobbies[i]);
}
function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} enjoyed for ${hobby.year} `)
}

let band1 = {
    name : "Pink Floyd",
    city : "London" ,
    country : "England",
    yearFormed : 1965,
    genres : ["Progressive rock", "psychedelic rock", "art rock"]
}
band1.genres = new Array("Progressive rock2", "psychedelic rock2", "art rock2");

let band2 = {
    name : "Ellicott City Band",
    city : "Ellicott City" ,
    country : "USA",
    yearFormed : 1985,
    genres : ["Melody", "Country Music", "International"]
}
band2.genres = new Array("Melody2", "Country Music2", "International 2");
let bandArray = [{band1, band2}];
printBandArray(bandArray);

function printBandArray(bandArray){
   for (let i =0; i < bands.length; i++) {
       console.log(` ${bands[0].name} , ${bands[0].city} , ${bands[0].country}
      , ${bands[0].yearFormed}`);
   }
}

