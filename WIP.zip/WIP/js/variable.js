let x, y, z;
x = 10;
y = '10';
z = 30;
console.log(`x is ${typeof x}`);
console.log(`y is ${typeof y}`);
console.log(`z is ${typeof z}`);
var newX = x++;
console.log(`newX is ` + newX);
if (x == y)
    console.log('x eqausl y');
else
    console.log('x not equals y');
let timeInMs = Date.now();
console.log('Todays millisecond: '+timeInMs);
var year = new Date();
var epochYear = new Date('01-01-1970');
console.log('epochYear millisecond: '+epochYear.getMilliseconds());
console.log('This year :' +year.getFullYear());
console.log('epoch year: ' +epochYear.getFullYear());
console.log('Number of Years: ' + (year.getFullYear() - epochYear.getFullYear()));
console.log('Number of Months: '+ ((year.getFullYear() - epochYear.getFullYear()) *12));
//console.log('Number of milliSeconds: ' + (year.getMilliseconds() - epochYear.getMilliseconds()));

