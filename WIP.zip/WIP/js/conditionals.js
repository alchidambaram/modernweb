let numOne = 1;
let stringOne = '1';
console.log("Is numOne and stringOne equals : " + (numOne == stringOne));
console.log("Is numOne and stringOne equals : " + (numOne === stringOne));
const day = new Date().getDay();
console.log('Day is: ' + day);
if (day == 0 || day == 6) {
    console.log('It is a weekDay');
} else if (day == 1) {
    console.log('Back to work');
} else if (day == 2 || day == 4 || day == 5) {
    console.log('It is a weekDay');
} else if (day == 3) {
    console.log("Over the hump!");
}