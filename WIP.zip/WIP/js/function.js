function displayName(a) {
    console.log('Hello ' + a);
}

displayName('Dany');
celciusToFarenheit(212, null);
celciusToFarenheit(null, 60);

function celciusToFarenheit(f, c) {
    if (f != null) {
        fToC = (f - 32) * 5 / 9;
        console.log('Farenhiet is ' + fToC);
    }
    else {
        cToF = c * (9 / 5) + 32;
        console.log('celcius is ' + cToF);
    }

}