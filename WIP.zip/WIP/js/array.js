let hobbies = ['art', 'sew', 'cook'];
printHobbies(hobbies);
let myColor = ["Red", "Green", "White", "Black"]; 
formatString(myColor);
function printHobbies(hobbies) {
    console.log('I like 3 things:');
    for (let p = 0; p < hobbies.length; p++) {
        console.log('I like ' + hobbies[p]);
    }
}

/*function formatString(myColor) {
    let concat;
    for (let p = 0; p < myColor.length; p++) {
       let
    } 
    console.log( myColor[p] + ',');
}*/