const hobbiesArray = [
    { name: 'volleyball', lengthInYearsAtHobby: 25 },
    { name: 'cooking', lengthInYearsAtHobby: 15 },
    { name: 'swimming', lengthInYearsAtHobby: 11 }
];

function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} has been an interest for ${hobby.lengthInYearsAtHobby} years`)
}

for (let p =0; p < hobbiesArray.length; p++) {
    printHobbyInfo(hobbiesArray[0]);
}


function returnHobbiesHtml(hobbiesArray) {
    let hobbyInfo =`<ul>`;
    
    hobbiesArray.forEach(hobby => {
        hobbyInfo+= `<li>${hobby.name} ${hobby.lengthInYearsAtHobby}</li>`;
        });
       hobbyInfo+=`</ul>`;
       console.log(`Printing hobbies: ${hobbyInfo}`)
    return hobbyInfo;
}

function returnHobbiesHtmlTable(hobbiesArray) {
    let hobbyInfo =`<table>`;
    
    hobbiesArray.forEach(hobby => {
        hobbyInfo+= `<tr><td>${hobby.name}</td><td> ${hobby.lengthInYearsAtHobby}</td></tr>`;
        });
       hobbyInfo +=`</table>`;
       console.log(`Printing hobbies: ${hobbyInfo}`)
    return hobbyInfo;
}